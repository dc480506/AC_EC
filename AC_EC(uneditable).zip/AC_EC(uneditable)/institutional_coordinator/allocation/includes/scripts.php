<!-- Bootstrap core JavaScript-->
<script src="../../vendor/jquery/jquery.min.js"></script>
<script src="../../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

<!-- Core plugin JavaScript-->
<script src="../../vendor/jquery-easing/jquery.easing.min.js"></script>

<!-- Custom scripts for all pages-->
<script src="../../vendor/js/sb-admin-2.min.js"></script>

<!-- Page level plugins -->
<script src="../../vendor/chart.js/Chart.min.js"></script>

<!-- Page level custom scripts -->
<script src="../../vendor/js/demo/chart-area-demo.js"></script>
<script src="../../vendor/js/demo/chart-bar-demo.js"></script>
<script src="../../vendor/js/demo/chart-pie-demo.js"></script>
<script src="../../vendor/js/demo/chart-horizontal-demo.js"></script>
<!-- Page level plugins -->
<script src="../../vendor/datatables/jquery.dataTables.min.js"></script>
<script src="../../vendor/datatables/dataTables.bootstrap4.min.js"></script>

<!-- Page level custom scripts -->
<script src="../../vendor/js/demo/datatables-demo.js"></script>
<script>

  
  function disp1() {
    var checkBox = document.getElementById("exampleCheck1");
    var field2 = document.getElementById("exampleFormControlSelect1");
    if (checkBox.checked == true) {
      field2.style.display = "block";

    } else {
      field2.style.display = "none";
    }
  }
  function disp2() {
    var checkBox = document.getElementById("exampleCheck2");
    var field2 = document.getElementById("exampleFormControlSelect2");
    if (checkBox.checked == true) {
      field2.style.display = "block";

    } else {
      field2.style.display = "none";
    }
  }
  function disp3() {
    var checkBox = document.getElementById("exampleCheck3");
    var field2 = document.getElementById("exampleFormControlSelect3");
    if (checkBox.checked == true) {
      field2.style.display = "block";

    } else {
      field2.style.display = "none";
    }
  }
  function disp4() {
    var checkBox = document.getElementById("exampleCheck4");
    var field2 = document.getElementById("exampleFormControlSelect4");
    if (checkBox.checked == true) {
      field2.style.display = "block";

    } else {
      field2.style.display = "none";
    }
  }
  function disp5(){
    var checkBox = document.getElementById("exampleCheck5");
    var field2 = document.getElementById("exampleFormControlSelect5");
    if (checkBox.checked == true) {
      field2.style.display = "block";

    } else {
      field2.style.display = "none";
    }
  }

  
</script>


</body>

</html>