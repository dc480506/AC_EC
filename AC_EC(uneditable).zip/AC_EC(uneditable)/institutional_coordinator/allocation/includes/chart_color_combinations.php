<?php
  $backgroundColor=array("#F7464A", "#46BFBD", "#FDB45C", "#949FB1", "#4D5360",
                        "#14213B","#9299DF","#F9CC80","#2DCADB","#E4BCBA","#6942C4");
  $hover_backgroundColor=array("#FF5A5E", "#5AD3D1", "#FFC870", "#A8B3C5", "#616774",
                              "#203159","#AFB5E0","#F5E18C","#5FE3FF","#EAC9D0","#9E72F4",);
?>