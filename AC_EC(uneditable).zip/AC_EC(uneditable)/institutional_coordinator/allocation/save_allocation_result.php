<?php
include_once('../verify.php');
include_once('../../config.php');

?>